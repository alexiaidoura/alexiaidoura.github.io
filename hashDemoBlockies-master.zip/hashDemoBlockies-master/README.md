# Hash Demo using Blockies
<img src='./blockies.png'>
This demo shows how hashes can be used to create document signatures. The Blockies is a pixel representation that makes it easier for the human to recognize particular hashes.