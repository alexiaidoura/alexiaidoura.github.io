var mit = {
    city: 'Cambridge',
    colors: ['pink', 'red'],
    mascot: "robot",
    founded: 1900,
    motto: 'Carpe diem',
};
