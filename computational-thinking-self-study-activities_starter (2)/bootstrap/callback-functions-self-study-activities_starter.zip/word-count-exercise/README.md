# wordCount
=======
count word occurance in long string
<img src='wordCount.png' />

